namespace WebAPI.Utilities
{
    public enum Flag
    {
        FeatureA
    }

}